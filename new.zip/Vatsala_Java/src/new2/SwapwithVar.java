package new2;

public class SwapwithVar {
	
	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=a;
		a=b;
		b=c;
		System.out.println(a);
		System.out.println(b);
	}

}
